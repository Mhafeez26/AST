package config;

import java.io.FileInputStream;
import java.util.Properties;

// testdata.properties se values parhta hai
public class ConfigReader {
    private static Properties properties;

    static {
        try {
            FileInputStream file = new FileInputStream("src/main/resources/testdata.properties");
            properties = new Properties();
            properties.load(file);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load config file");
        }
    }

    public static String getProperty(String key) {
        return properties.getProperty(key);
    }
}
