package tests;

import base.BaseTest;
import config.ConfigReader;
import org.openqa.selenium.WindowType;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.CartPage;
import pages.ContactPage;
import pages.ShopPage;

import java.io.IOException;

public class AssignmentTest extends BaseTest {
    ShopPage shopPage;
    CartPage cartPage;
    ContactPage contactPage;

    double unitPrice; // item page par dikhi hui price (test 2 me bhi use hogi)

    @BeforeClass
    public void initPages() {
        shopPage = new ShopPage(driver);
        cartPage = new CartPage(driver);
        contactPage = new ContactPage(driver);
    }

    // Test 1: item search karo, cart me dalo, quantity aur amount check karo
    @Test(priority = 1)
    public void testAddToCart() throws InterruptedException {
        shopPage.searchItem(ConfigReader.getProperty("searchText"));
        shopPage.openFirstItem();

        unitPrice = toNumber(shopPage.getPriceText());

        shopPage.addToCart();
        Thread.sleep(2000);
        shopPage.openCart();

        int expectedQty = Integer.parseInt(ConfigReader.getProperty("expectedQtyBefore"));
        Assert.assertEquals(cartPage.getQuantity(), expectedQty, "Quantity galat hai");
        Assert.assertEquals(toNumber(cartPage.getTotalText()), unitPrice * expectedQty, 0.01, "Amount galat hai");
    }

    // Test 2: quantity +1 karo, total check karo, screenshot lo
    @Test(priority = 2, dependsOnMethods = "testAddToCart")
    public void testUpdateQuantity() throws InterruptedException, IOException {
        cartPage.increaseQuantity();
        Thread.sleep(3000); // cart update hone ka wait

        int expectedQty = Integer.parseInt(ConfigReader.getProperty("expectedQtyAfter"));
        Assert.assertEquals(cartPage.getQuantity(), expectedQty, "Quantity update nahi hui");
        Assert.assertEquals(toNumber(cartPage.getTotalText()), unitPrice * expectedQty, 0.01, "Total update nahi hua");

        takeScreenshot(ConfigReader.getProperty("cartScreenshot"));
    }

    // Test 3: naye tab me contact form bharo, submit karo, screenshot lo
    @Test(priority = 3)
    public void testContactForm() throws IOException {
        driver.switchTo().newWindow(WindowType.TAB);
        driver.get(ConfigReader.getProperty("contactUrl"));

        contactPage.fillForm(
                ConfigReader.getProperty("firstName"),
                ConfigReader.getProperty("lastName"),
                ConfigReader.getProperty("email"),
                ConfigReader.getProperty("subject"),
                ConfigReader.getProperty("message"),
                ConfigReader.getProperty("uploadFile"));
        contactPage.submit();

        String successText = contactPage.getSuccessText();
        Assert.assertTrue(successText.contains(ConfigReader.getProperty("successText")), "Form submit nahi hua");

        takeScreenshot(ConfigReader.getProperty("contactScreenshot"));
    }
}
