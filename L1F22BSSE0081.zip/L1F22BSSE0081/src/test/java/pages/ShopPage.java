package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ShopPage {
    WebDriver driver;

    public ShopPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // TODO: Inspect karke apni site ke hisaab se in locators ko badlo
    @FindBy(css = "input[name='q']")
    WebElement searchBox;

    @FindBy(xpath = "(//a[contains(@href,'/products/')])[1]")
    WebElement firstProduct;

    @FindBy(css = ".price")
    WebElement productPrice;

    @FindBy(css = "button[name='add']")
    WebElement addToCartButton;

    @FindBy(xpath = "//a[contains(@href,'/cart')]")
    WebElement cartLink;

    public void searchItem(String text) {
        searchBox.sendKeys(text);
        searchBox.sendKeys(Keys.ENTER);
    }

    public void openFirstItem() {
        firstProduct.click();
    }

    public String getPriceText() {
        return productPrice.getText();
    }

    public void addToCart() {
        addToCartButton.click();
    }

    public void openCart() {
        cartLink.click();
    }
}
