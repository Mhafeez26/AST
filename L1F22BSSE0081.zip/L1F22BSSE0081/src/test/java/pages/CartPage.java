package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CartPage {
    WebDriver driver;

    public CartPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // TODO: Inspect karke apni site ke hisaab se in locators ko badlo
    @FindBy(css = "input[name='updates[]']")
    WebElement quantityField;

    @FindBy(css = "button[name='plus']")
    WebElement plusButton;

    @FindBy(css = ".cart-item__totals .price")
    WebElement itemTotal;

    public int getQuantity() {
        return Integer.parseInt(quantityField.getAttribute("value"));
    }

    public String getTotalText() {
        return itemTotal.getText();
    }

    public void increaseQuantity() {
        plusButton.click();
    }
}
