package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.time.Duration;

public class ContactPage {
    WebDriver driver;

    public ContactPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Locators (agar na milein to Inspect karke check kar lo)
    @FindBy(css = "[data-test='first-name']")
    WebElement firstName;

    @FindBy(css = "[data-test='last-name']")
    WebElement lastName;

    @FindBy(css = "[data-test='email']")
    WebElement email;

    @FindBy(css = "[data-test='subject']")
    WebElement subject;

    @FindBy(css = "[data-test='message']")
    WebElement message;

    @FindBy(css = "[data-test='attachment']")
    WebElement attachment;

    @FindBy(css = "[data-test='contact-submit']")
    WebElement submitButton;

    @FindBy(css = ".alert-success")
    WebElement successMessage;

    // Poora form bharta hai aur file upload karta hai
    public void fillForm(String first, String last, String mail, String sub, String msg, String filePath) {
        firstName.sendKeys(first);
        lastName.sendKeys(last);
        email.sendKeys(mail);
        new Select(subject).selectByVisibleText(sub);
        message.sendKeys(msg);
        // file input me full path bhejne se file upload ho jati hai
        attachment.sendKeys(new File(filePath).getAbsolutePath());
    }

    public void submit() {
        submitButton.click();
    }

    // Success message aane tak ruk kar uska text deta hai
    public String getSuccessText() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(successMessage));
        return successMessage.getText();
    }
}
